Quasar SMP - Elytra wing item models
Minecraft Java Edition 1.21.11

INSTALL:
1. Put this ZIP into .minecraft/resourcepacks, or host it as the server resource pack.
2. Enable the pack in Minecraft.
3. Use the commands below to create the custom items.

RIGHT WING:
 /give @s minecraft:elytra[minecraft:custom_name='{"text":"Правое крыло","color":"light_purple","italic":false}',minecraft:equippable={asset_id:"minecraft:elytra",damage_on_hurt:false,equip_sound:"minecraft:item.armor.equip_elytra",slot:"mainhand"},minecraft:lore=['{"text":"Правое яйцо","color":"white","italic":false}'],minecraft:max_damage=1,minecraft:repair_cost=9999,minecraft:custom_model_data={strings:["quasar:right_wing"]}] 1

LEFT WING:
 /give @s minecraft:elytra[minecraft:custom_name='{"text":"Левое крыло","color":"light_purple","italic":false}',minecraft:equippable={asset_id:"minecraft:elytra",damage_on_hurt:false,equip_sound:"minecraft:item.armor.equip_elytra",slot:"mainhand"},minecraft:lore=['{"text":"Левое яйцо","color":"white","italic":false}'],minecraft:max_damage=1,minecraft:repair_cost=9999,minecraft:custom_model_data={strings:["quasar:left_wing"]}] 1

HOW IT WORKS:
- The resource pack checks minecraft:custom_model_data strings.
- "quasar:right_wing" displays the supplied right-wing texture.
- "quasar:left_wing" displays the supplied left-wing texture.
- Ordinary elytra without these strings keep the default model.

IMPORTANT:
- The supplied custom_model_data strings are the unique visual identifiers. Add them to your existing items; the NBT you supplied did not include a model identifier yet.
- Resource-pack model selection is not security: players with commands/NBT editing permission can copy the strings.
- This pack changes the inventory/item icon only. It does not create a 3D player-back model.
- The lore text was kept exactly as supplied ("Правое яйцо" / "Левое яйцо"). Change it in the commands if that was a typo.
